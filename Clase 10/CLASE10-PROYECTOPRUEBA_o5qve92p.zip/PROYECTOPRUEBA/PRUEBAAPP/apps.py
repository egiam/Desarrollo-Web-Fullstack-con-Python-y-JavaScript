from django.apps import AppConfig


class PruebaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PRUEBAAPP'
